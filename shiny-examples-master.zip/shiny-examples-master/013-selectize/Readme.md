The function `selectizeInput()` creates a select input extended by
[selectize.js](https://github.com/brianreavis/selectize.js). You can type and
search in the input box, delete selected items, set placeholders, and add new
options by typing in the input box, etc.
