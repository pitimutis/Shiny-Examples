
    textInput(inputId, label, value = "")

    
Create a text field to enter text in. The widget will pass the text displayed to the server as a character string.

##### Arguments

`inputId` 
The name to use to look up the value of the widget (as a character string)

`label` 
A label to display above the text field

`value`
The initial text to display in the box, if any

_Make this widget by copying the code in ui.R._
